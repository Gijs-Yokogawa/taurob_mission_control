# gui/template_gui.py

import tkinter as tk
from tkinter import ttk, messagebox
import json
from models.template_generator import generate_empty_checkpoint_template
from storage.manager import save_checkpoint
from pathlib import Path

TEMPLATE_OUTPUT_PATH = Path("checkpoints/templates")
TEMPLATE_OUTPUT_PATH.mkdir(parents=True, exist_ok=True)

def launch_template_generator(parent):
    """
    parent: de hoofd-Tk() of Toplevel() waar dit venster aan hangt.
    """
    win = tk.Toplevel(parent)
    win.title("Genereer Leeg Checkpoint Template")

    frm = ttk.Frame(win, padding=10)
    frm.grid(sticky='nsew')
    frm.columnconfigure(1, weight=1)

    # Naam van checkpoint
    ttk.Label(frm, text="Naam van Checkpoint:").grid(column=0, row=0, sticky='w')
    name_entry = ttk.Entry(frm)
    name_entry.grid(column=1, row=0, sticky='ew')

    # Type checkpoint
    ttk.Label(frm, text="Type Checkpoint:").grid(column=0, row=1, sticky='w')
    type_menu = ttk.Combobox(
        frm,
        values=['drive', 'dock', 'measure'],
        state='readonly'
    )
    type_menu.grid(column=1, row=1, sticky='ew')
    type_menu.set('drive')

    def on_generate():
        name = name_entry.get().strip()
        ctype = type_menu.get().strip().lower()

        try:
            template = generate_empty_checkpoint_template(name, ctype)
        except ValueError as e:
            messagebox.showerror("Ongeldig checkpoint type", str(e), parent=win)
            return

        # schrijf JSON
        filename = f"{name.replace(' ', '_')}_{ctype}.json"
        out_path = TEMPLATE_OUTPUT_PATH / filename
        with open(out_path, 'w') as f:
            json.dump(template, f, indent=2)

        # opslaan in checkpoints.json
        save_checkpoint(template, checkpoint_id=-1)

        # stuur event zodat andere vensters kunnen updaten
        parent.event_generate('<<CheckpointAdded>>', when='tail')

        messagebox.showinfo(
            "Succes",
            f"Template opgeslagen als:\n{out_path.name}\nType: {ctype}",
            parent=win
        )
        win.destroy()  # sluit het generator-venster als je wilt

    ttk.Button(frm, text="Genereer Template", command=on_generate)\
        .grid(column=0, row=2, columnspan=2, pady=10, sticky='ew')
