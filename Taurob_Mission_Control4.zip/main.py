from gui.login import login_and_then
from gui.interface import show_main_menu

if __name__ == '__main__':
    login_and_then(show_main_menu)
