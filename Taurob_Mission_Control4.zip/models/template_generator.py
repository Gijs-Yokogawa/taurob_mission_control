# models/template_generator.py

def generate_empty_checkpoint_template(name: str, checkpoint_type: str) -> dict:
    if not name.strip():
        raise ValueError("Naam van checkpoint mag niet leeg zijn.")

    raw = checkpoint_type.strip()
    ctype = raw.lower()
    valid = ['drive', 'dock', 'measure']
    if ctype not in valid:
        raise ValueError(
            f"'{raw}' is geen geldig checkpoint type. "
            f"Kies uit: {', '.join(valid)}"
        )

    # Basistemplate
    template = {
        "ActionName": name,
        "ActionType": ctype,
        "RobotPose": "",
        "ActionInfo": "",
        "Metadata": ""
    }

    # Dock & Measure hebben extra veld AssetName
    if ctype in ['dock', 'measure']:
        template["AssetName"] = ""

    return template
