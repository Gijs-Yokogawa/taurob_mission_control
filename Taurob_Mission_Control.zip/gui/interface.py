import tkinter as tk
from tkinter import ttk, messagebox
from threading import Thread
from api.client import create_checkpoint
from models.checkpoint import build_checkpoint_json, validate_checkpoint_input
from storage.manager import save_checkpoint

checkpoint_types = ['Drive', 'Measurement', 'Docking']

def launch_gui(session_token: str):
    root = tk.Tk()
    root.title("Fleet Checkpoint Manager")

    frm = ttk.Frame(root, padding=10)
    frm.grid()

    ttk.Label(frm, text="Checkpoint Type:").grid(column=0, row=0, sticky='w')
    type_var = tk.StringVar(value='Drive')
    type_menu = ttk.Combobox(frm, textvariable=type_var, values=checkpoint_types)
    type_menu.grid(column=1, row=0)

    ttk.Label(frm, text="Robot Name:").grid(column=0, row=1, sticky='w')
    robot_entry = ttk.Entry(frm)
    robot_entry.insert(0, "karl")
    robot_entry.grid(column=1, row=1)

    ttk.Label(frm, text="X:").grid(column=0, row=2, sticky='w')
    x_entry = ttk.Entry(frm)
    x_entry.grid(column=1, row=2)

    ttk.Label(frm, text="Y:").grid(column=0, row=3, sticky='w')
    y_entry = ttk.Entry(frm)
    y_entry.grid(column=1, row=3)

    ttk.Label(frm, text="Yaw:").grid(column=0, row=4, sticky='w')
    yaw_entry = ttk.Entry(frm)
    yaw_entry.grid(column=1, row=4)

    ttk.Label(frm, text="Extra (opt):").grid(column=0, row=5, sticky='w')
    extra_entry = ttk.Entry(frm)
    extra_entry.grid(column=1, row=5)

    def on_submit():
        try:
            x = float(x_entry.get())
            y = float(y_entry.get())
            yaw = float(yaw_entry.get())
            extra = extra_entry.get()
            robot_name = robot_entry.get()
            checkpoint_type = type_var.get()

            validate_checkpoint_input(checkpoint_type, x, y, yaw, extra, robot_name)
            checkpoint_data = build_checkpoint_json(checkpoint_type, x, y, yaw, extra, robot_name)

            def api_task():
                try:
                    checkpoint_id = create_checkpoint(checkpoint_data, session_token)
                    save_checkpoint(checkpoint_data, checkpoint_id)
                    messagebox.showinfo("Success", f"Created {checkpoint_type} checkpoint with ID: {checkpoint_id}")
                except Exception as e:
                    messagebox.showerror("API Error", str(e))

            Thread(target=api_task).start()
        except ValueError as e:
            messagebox.showerror("Input Error", str(e))

    ttk.Button(frm, text="Create Checkpoint", command=on_submit).grid(column=0, row=6, columnspan=2, pady=10)

    root.mainloop()
