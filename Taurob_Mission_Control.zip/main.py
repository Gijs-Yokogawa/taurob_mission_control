from gui.login import show_login_screen

if __name__ == '__main__':
    show_login_screen()
