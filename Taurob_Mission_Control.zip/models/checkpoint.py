from datetime import datetime
import json

def build_checkpoint_json(checkpoint_type: str, x: float, y: float, yaw: float, extra: str, robot_name: str) -> dict:
    base_pose = {
        "floor": "level1" if checkpoint_type != 'Drive' else "ground",
        "position": {"x": x, "y": y, "z": 0.0},
        "orientation": {"x": 0.0, "y": 0.0, "z": 0.004, "w": 1.0},
        "x": x,
        "y": y,
        "theta": yaw
    }

    robot_pose = {}
    if checkpoint_type == "Measurement":
        robot_pose[robot_name] = {
            "arm_pose": json.dumps({
                "joint_positions": {
                    "arm_joint_1": 3.753,
                    "arm_joint_2": 3.056,
                    "arm_joint_3": 0.641,
                    "arm_joint_4": 2.892,
                    "arm_joint_5": 2.24
                }
            }),
            "base_pose": json.dumps(base_pose)
        }
    elif checkpoint_type == "Drive":
        robot_pose = {
            robot_name: {"base_pose": json.dumps(base_pose)},
            "jerry": {"base_pose": json.dumps(base_pose)}
        }
    else:  # Docking
        robot_pose[robot_name] = {"base_pose": json.dumps(base_pose)}

    data = {
        "ActionName": f"Checkpoint ({checkpoint_type}) @ ({x}, {y})",
        "ActionType": checkpoint_type.lower() if checkpoint_type != "Docking" else "dock",
        "RobotPose": json.dumps(robot_pose),
        "ActionInfo": ""
    }

    if checkpoint_type in ["Docking", "Measurement"]:
        data["AssetName"] = extra if extra.strip() else "UNKNOWN"

    if checkpoint_type == "Docking":
        data["Metadata"] = json.dumps({
            "docking": {"undock_drive_time": 10, "dock_drive_time": 12},
            "safe_spot": True
        })
    elif checkpoint_type == "Measurement":
        data["Metadata"] = json.dumps({
            "apps": ["emailer"],
            "measurement": {
                "duration": 10,
                "result_type": "video",
                "sensor_name": "camera_sensorhead",
                "format": "video/mp4"
            }
        })
    else:
        data["Metadata"] = ""

    return data

def validate_checkpoint_input(checkpoint_type: str, x: float, y: float, yaw: float, extra: str, robot_name: str):
    if not isinstance(x, float) or not isinstance(y, float) or not isinstance(yaw, float):
        raise ValueError("X, Y en Yaw moeten numeriek zijn.")
    if checkpoint_type in ['Docking', 'Measurement'] and extra.strip() == "":
        raise ValueError("AssetName is verplicht voor Docking en Measurement.")
    if checkpoint_type not in ['Drive', 'Measurement', 'Docking']:
        raise ValueError("Ongeldig checkpoint type.")
    if not robot_name.strip():
        raise ValueError("Robotnaam mag niet leeg zijn.")
