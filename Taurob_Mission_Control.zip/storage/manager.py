import json
from pathlib import Path

CHECKPOINT_FILE = Path("checkpoints/checkpoints.json")
CHECKPOINT_FILE.parent.mkdir(parents=True, exist_ok=True)
if not CHECKPOINT_FILE.exists():
    with open(CHECKPOINT_FILE, 'w') as f:
        json.dump([], f)

def save_checkpoint(data: dict, checkpoint_id: int):
    entry = {"id": checkpoint_id, **data}
    with open(CHECKPOINT_FILE, 'r+') as f:
        try:
            existing = json.load(f)
        except json.JSONDecodeError:
            existing = []
        existing.append(entry)
        f.seek(0)
        json.dump(existing, f, indent=2)
        f.truncate()
