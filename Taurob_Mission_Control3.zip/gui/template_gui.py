# gui/template_gui.py

import tkinter as tk
from tkinter import ttk, messagebox
import json
from models.template_generator import generate_empty_checkpoint_template
from storage.manager import save_checkpoint
from pathlib import Path

TEMPLATE_OUTPUT_PATH = Path("checkpoints/templates")
TEMPLATE_OUTPUT_PATH.mkdir(parents=True, exist_ok=True)

def launch_template_generator():
    root = tk.Tk()
    root.title("Genereer Leeg Checkpoint Template")

    frm = ttk.Frame(root, padding=10)
    frm.grid()

    ttk.Label(frm, text="Naam van Checkpoint:").grid(column=0, row=0, sticky='w')
    name_entry = ttk.Entry(frm)
    name_entry.grid(column=1, row=0)

    ttk.Label(frm, text="Type Checkpoint:").grid(column=0, row=1, sticky='w')
    type_var = tk.StringVar(value='drive')
    type_menu = ttk.Combobox(frm, textvariable=type_var, values=['drive', 'dock', 'measure'])
    type_menu.grid(column=1, row=1)

    def on_generate():
        name = name_entry.get()
        ctype = type_var.get()
        try:
            template = generate_empty_checkpoint_template(name, ctype)
            filename = f"{name.replace(' ', '_')}_{ctype}.json"
            out_path = TEMPLATE_OUTPUT_PATH / filename
            with open(out_path, 'w') as f:
                json.dump(template, f, indent=2)

            # Save also in global checkpoints.json
            save_checkpoint(template, checkpoint_id=-1)  # use -1 to indicate template

            messagebox.showinfo("Success", f"Template opgeslagen als: {out_path} en toegevoegd aan checkpoints.json")
        except Exception as e:
            messagebox.showerror("Fout", str(e))

    ttk.Button(frm, text="Genereer Template", command=on_generate).grid(column=0, row=2, columnspan=2, pady=10)

    root.mainloop()