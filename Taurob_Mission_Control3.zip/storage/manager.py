# storage/manager.py

import sqlite3
from pathlib import Path
import json

DB_PATH = Path("checkpoints/checkpoints.db")
DB_PATH.parent.mkdir(parents=True, exist_ok=True)

# Create the table if it doesn't exist
def init_db():
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS checkpoints (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                checkpoint_id INTEGER,
                type TEXT,
                name TEXT,
                json TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        conn.commit()

init_db()

def save_checkpoint(data: dict, checkpoint_id: int):
    name = data.get("ActionName", "UNKNOWN")
    ctype = data.get("ActionType", "unknown")
    json_str = json.dumps(data, indent=2)

    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO checkpoints (checkpoint_id, type, name, json)
            VALUES (?, ?, ?, ?)
        ''', (checkpoint_id, ctype, name, json_str))
        conn.commit()

def load_all_checkpoints():
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute('SELECT checkpoint_id, type, name, json, created_at FROM checkpoints ORDER BY created_at DESC')
        return cursor.fetchall()
