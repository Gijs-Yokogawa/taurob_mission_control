def generate_empty_checkpoint_template(name: str, checkpoint_type: str) -> dict:
    if not name.strip():
        raise ValueError("Naam van checkpoint mag niet leeg zijn.")

    if checkpoint_type not in ["drive", "dock", "measure"]:
        raise ValueError("Ongeldig checkpoint type. Kies uit: drive, dock, measure")

    base = {
        "ActionName": name,
        "ActionType": checkpoint_type,
        "RobotPose": "",
        "ActionInfo": ""
    }

    if checkpoint_type == "dock":
        base["AssetName"] = ""
        base["Metadata"] = ""
    elif checkpoint_type == "measure":
        base["AssetName"] = ""
        base["Metadata"] = ""
    elif checkpoint_type == "drive":
        base["Metadata"] = ""

    return base