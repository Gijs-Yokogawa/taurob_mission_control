# gui/checkpoint_viewer.py — robot entry now starts empty

import tkinter as tk
from tkinter import ttk, messagebox
import json
import requests
from requests.auth import HTTPBasicAuth
from storage.manager import load_all_checkpoints, save_checkpoint
from urllib3.exceptions import InsecureRequestWarning

requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)

API_URL_TEMPLATE = "https://10.1.0.1:8443/basic/mission_editor/data_model/editor/action/all?robot_name={}"

def launch_checkpoint_viewer(parent, username, password):
    viewer = tk.Toplevel(parent)
    viewer.title("Bekijk Checkpoints")

    frm = ttk.Frame(viewer, padding=10)
    frm.grid(sticky="nsew")
    viewer.rowconfigure(0, weight=1)
    viewer.columnconfigure(0, weight=1)

    robot_label = ttk.Label(frm, text="Robot Naam:")
    robot_label.grid(row=0, column=0, sticky='w')
    robot_entry = ttk.Entry(frm)
    robot_entry.grid(row=0, column=1, sticky='we')  # now starts empty

    columns = ("id", "type", "name", "created")
    tree = ttk.Treeview(frm, columns=columns, show='headings')
    for col in columns:
        tree.heading(col, text=col.capitalize(), command=lambda c=col: sort_treeview(tree, c, False))
        tree.column(col, anchor='w')
    tree.grid(row=1, column=0, columnspan=3, sticky="nsew")

    def sort_treeview(tree, col, reverse):
        def convert(value):
            try:
                return int(value)
            except (ValueError, TypeError):
                return value.lower() if isinstance(value, str) else value
        data = [(convert(tree.set(k, col)), k) for k in tree.get_children('')]
        data.sort(reverse=reverse)
        for index, (_, k) in enumerate(data):
            tree.move(k, '', index)
        tree.heading(col, command=lambda: sort_treeview(tree, col, not reverse))

    def sync_from_api():
        robot_name = robot_entry.get().strip()
        if not robot_name:
            messagebox.showerror("Fout", "Robotnaam is leeg")
            return
        try:
            url = API_URL_TEMPLATE.format(robot_name)
            response = requests.get(url, auth=HTTPBasicAuth(username, password), verify=False)
            response.raise_for_status()
            actions = response.json()
            tree.delete(*tree.get_children())
            for action in actions:
                checkpoint_id = action.get("ActionID", -1)
                save_checkpoint(action, checkpoint_id)
                tree.insert('', 'end', values=(
                    checkpoint_id,
                    action.get("ActionType", "-"),
                    action.get("ActionName", "-"),
                    "API import"
                ))
            messagebox.showinfo("Success", f"{len(actions)} checkpoints geïmporteerd van robot '{robot_name}'")
        except Exception as e:
            messagebox.showerror("Fout bij API", str(e))

    ttk.Button(frm, text="Sync van Robot API", command=sync_from_api).grid(row=0, column=2, padx=5)

    frm.rowconfigure(1, weight=1)
    frm.columnconfigure(0, weight=1)
    scrollbar = ttk.Scrollbar(frm, orient="vertical", command=tree.yview)
    tree.configure(yscroll=scrollbar.set)
    scrollbar.grid(row=1, column=3, sticky="ns")

    details_box = tk.Text(frm, height=15, width=80)
    details_box.grid(row=2, column=0, columnspan=4, pady=10)

    def on_select(event):
        selected = tree.selection()
        if not selected:
            return
        item = tree.item(selected[0])
        values = item["values"]
        full = next((c for c in load_all_checkpoints() if str(c[0]) == str(values[0])), None)
        if full:
            json_str = json.loads(full[3])
            details_box.delete("1.0", tk.END)
            details_box.insert(tk.END, json.dumps(json_str, indent=2))

    tree.bind("<<TreeviewSelect>>", on_select)

    try:
        checkpoints = load_all_checkpoints()
        for chk in checkpoints:
            tree.insert('', 'end', values=(chk[0], chk[1], chk[2], chk[4]))
    except Exception as e:
        messagebox.showerror("Fout bij laden", str(e))
