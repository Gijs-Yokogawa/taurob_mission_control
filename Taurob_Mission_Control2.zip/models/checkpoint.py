# models/checkpoint.py — Combined builder + generator

import json

def build_checkpoint_json(checkpoint_type, x, y, yaw, extra, robot_name):
    base_pose = {
        "floor": "level1",
        "position": {"x": x, "y": y, "z": 0.0},
        "orientation": {"x": 0.0, "y": 0.0, "z": 0.004, "w": 1.0},
        "x": x,
        "y": y,
        "theta": yaw
    }

    robot_pose = {}
    if checkpoint_type == "measure":
        robot_pose[robot_name] = {
            "arm_pose": json.dumps({
                "joint_positions": {
                    "arm_joint_1": 3.753,
                    "arm_joint_2": 3.056,
                    "arm_joint_3": 0.641,
                    "arm_joint_4": 2.892,
                    "arm_joint_5": 2.24
                }
            }),
            "base_pose": json.dumps(base_pose)
        }
    elif checkpoint_type == "drive":
        robot_pose = {
            robot_name: {"base_pose": json.dumps(base_pose)},
            "jerry": {"base_pose": json.dumps(base_pose)}
        }
    else:  # dock
        robot_pose[robot_name] = {"base_pose": json.dumps(base_pose)}

    data = {
        "ActionName": f"Generated {checkpoint_type.title()} Checkpoint",
        "ActionType": "dock" if checkpoint_type == "dock" else checkpoint_type,
        "RobotPose": json.dumps(robot_pose),
        "ActionInfo": "",
        "Metadata": extra or ""
    }

    if checkpoint_type in ["dock", "measure"]:
        data["AssetName"] = ""

    return data

def validate_checkpoint_input(checkpoint_type, x, y, yaw, extra, robot_name):
    if checkpoint_type not in ["drive", "measure", "dock"]:
        raise ValueError("Ongeldig checkpoint type")
    if not robot_name.strip():
        raise ValueError("Robotnaam is verplicht")


def generate_filled_template(name: str, checkpoint_type: str, robot_name: str, floor: str) -> dict:
    if not name.strip():
        raise ValueError("Naam mag niet leeg zijn.")
    if not robot_name.strip():
        raise ValueError("Robotnaam mag niet leeg zijn.")
    if checkpoint_type not in ["drive", "measure", "dock"]:
        raise ValueError("Ongeldig checkpoint type.")

    x, y, theta = 0.0, 0.0, 0.0
    base_pose = {
        "floor": floor,
        "position": {"x": x, "y": y, "z": 0.0},
        "orientation": {"x": 0.0, "y": 0.0, "z": 0.004, "w": 1.0},
        "x": x,
        "y": y,
        "theta": theta
    }

    robot_pose = {}
    if checkpoint_type == "measure":
        robot_pose[robot_name] = {
            "arm_pose": json.dumps({
                "joint_positions": {
                    "arm_joint_1": 3.753,
                    "arm_joint_2": 3.056,
                    "arm_joint_3": 0.641,
                    "arm_joint_4": 2.892,
                    "arm_joint_5": 2.24
                }
            }),
            "base_pose": json.dumps(base_pose)
        }
    elif checkpoint_type == "drive":
        robot_pose = {
            robot_name: {"base_pose": json.dumps(base_pose)},
            "jerry": {"base_pose": json.dumps(base_pose)}
        }
    else:
        robot_pose[robot_name] = {"base_pose": json.dumps(base_pose)}

    data = {
        "ActionName": name,
        "ActionType": "dock" if checkpoint_type == "dock" else checkpoint_type,
        "RobotPose": json.dumps(robot_pose),
        "ActionInfo": "",
        "Metadata": ""
    }

    if checkpoint_type in ["dock", "measure"]:
        data["AssetName"] = ""

    return data
